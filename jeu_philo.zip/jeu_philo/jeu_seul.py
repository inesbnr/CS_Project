import pygame
import sys

# Initialisation de Pygame
pygame.init()

# Dimensions de la fenêtre
largeur, hauteur = 800, 800

# Dimensions d'une cellule du quadrillage
taille_case = 10

# Couleurs
BLANC = (255, 255, 255)
NOIR = (0, 0, 0)
ROUGE = (255, 0, 0)
VERT = (0, 255, 0)
BLEU = (0, 0, 255)

# Initialisation de la fenêtre
ecran = pygame.display.set_mode((largeur, hauteur))
pygame.display.set_caption("°°°°°°°°°°°°°   GAME : TORN   °°°°°°°°°°°°")

class Player:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.direction_x = 1
        self.direction_y = 0
        self.color = color

    def move(self):
        self.x += self.direction_x * taille_case
        self.y += self.direction_y * taille_case

# Initialisation du joueur
player = Player(largeur // 2, hauteur // 2, BLEU)

# Initialisation de la grille
grille = [[0 for _ in range(largeur // taille_case)] for _ in range(hauteur // taille_case)]

# Fonction pour redémarrer le jeu
def restart_game():
    global grille, player
    grille = [[0 for _ in range(largeur // taille_case)] for _ in range(hauteur // taille_case)]
    player = Player(largeur // 2, hauteur // 2, BLEU)

# Boucle principale
perdu = False

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if not perdu:
                if event.key == pygame.K_UP and player.direction_y != 1:
                    player.direction_x, player.direction_y = 0, -1
                elif event.key == pygame.K_DOWN and player.direction_y != -1:
                    player.direction_x, player.direction_y = 0, 1
                elif event.key == pygame.K_LEFT and player.direction_x != 1:
                    player.direction_x, player.direction_y = -1, 0
                elif event.key == pygame.K_RIGHT and player.direction_x != -1:
                    player.direction_x, player.direction_y = 1, 0

    if not perdu:
        # Met à jour la position du joueur
        player.move()

        # Vérifie si le joueur a perdu en touchant un bord de l'écran
        if player.x < 0 or player.x >= largeur or player.y < 0 or player.y >= hauteur:
            perdu = True

        # Vérifie si le joueur a perdu en repassant sur une case déjà colorée
        elif grille[player.y // taille_case][player.x // taille_case] == 1:
            perdu = True

        # Marque la case comme visitée
        else:
            grille[player.y // taille_case][player.x // taille_case] = 1

    # Dessine le joueur et le quadrillage
    ecran.fill(BLANC)

    for i in range(len(grille)):
        for j in range(len(grille[0])):
            if grille[i][j] == 1:
                pygame.draw.rect(ecran, player.color, (j * taille_case, i * taille_case, taille_case, taille_case))

    if not perdu:
        pygame.draw.rect(ecran, player.color, (player.x, player.y, taille_case, taille_case))
    else:
        # Affiche un bouton "Restart" s'il y a eu une perte
        font = pygame.font.Font(None, 60)
        text_surface = font.render("GAME OVER", True, ROUGE)
        text_rect = text_surface.get_rect(center=(largeur // 2, hauteur // 2 - 50))
        texte_restart = font.render("Restart", True, NOIR)
        rect_restart = texte_restart.get_rect(center=(largeur // 2, hauteur // 2))
        pygame.draw.rect(ecran, VERT, rect_restart, border_radius=5)
        ecran.blit(text_surface, text_rect)
        ecran.blit(texte_restart, rect_restart)

        # Si le joueur a perdu et clique sur "Restart"
        mouse_pos = pygame.mouse.get_pos()
        if rect_restart.collidepoint(mouse_pos):
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    restart_game()
                    perdu = False

    # Met à jour l'écran
    pygame.display.flip()

    pygame.time.Clock().tick(10)

