# Jeu 'Torn'

## Règles du jeu

Le jeu 'Torn' est un jeu en ligne où les joueurs se déplacent à vitesse constante à l'aide des flèches du clavier. 
Le joueur peut changer de direction en utilisant les flèches.
L'écran de jeu est divisé en un quadrillage sur lequel le joueur se déplace. 
Chaque fois qu'il passe par une case, celle-ci se colore selon la couleur du joueur. 
Si le joueur passe par une case déjà colorée (par lui-même ou un autre joueur), il meurt. 
S'il touche les bordures de l'écran, il meurt également.
Le joueur gagnant est celui qui reste le plus longtemps sur le plateau de jeu.

## Table des matières
1. [Installation](#installation)
2. [Utilisation](#utilisation)
3. [Avancements_&_Obstacles](#Avancements_&_Obstacles)
4. [Auteurs](#auteurs)

## Installation

Suivez ces étapes pour installer et exécuter le jeu 'Torn' sur votre système :

1. **Téléchargement du jeu :**
   - Téléchargez les fichiers du jeu 

2. **Extraction du fichier ZIP :**
   - Décompressez le fichier ZIP que vous avez téléchargé dans le répertoire de votre choix.

3. **Connectez-vous au réseau :**
   - Changer l'adresse ip du réseauparc elle quevous utilisez.

4. **Lancement du jeu :**
   - Ouvrez les fichiers `server.py`et 'client.py dans VScode.
   - Lancer le ficher server puis le ficher client

6. **Prêt à jouer :**
   - Le jeu commence, lorsque la partie est terminée appuyer sur "Restart" ou fermer la fenêtre. 



## Configuration

(Votre description des étapes de configuration)

## Utilisation 

Ce jeu est simple à utiliser : une fois la partie lancée, 
le joueur n'a qu'à changer de direction en utilisant les flèches de son clavier et éviter de toucher les obstacles 
(bordures de l'écran et passages des autres joueurs).
Lorsque la partie est terminée, un bouton "Restart" apparaît, le joueur n'a qu'à cliquer dessus pour recommencer une partie.


##Avancements & Obstacles

Dans le processus de création de notre programme, nous avons initialement concentré nos efforts sur l'architecture client/serveur,
 en veillant à ce que les informations circulent de manière fluide.

Dans un premier temps, nous avons développé le jeu pour un joueur, 
en intégrant toutes les conditions et contraintes essentielles, telles que le déplacement, les obstacles, les bordures de l'écran, etc.

En parallèle, nous avons mis en place les classes nécessaires pour créer un joueur, 
transmettre ses données aux autres clients et recevoir les leurs.

Par la suite, nous avons intégré le jeu dans le programme client/serveur, 
permettant ainsi la communication entre différents joueurs au sein d'une même partie.

Nous avons rencontré certains défis lors de cette étape, 
notamment la synchronisation des mouvements entre les joueurs et la gestion des collisions de manière efficace. 

Si l'on devait améliorer ceprogramme, nous essaierons d'enrichir les fonctionnalités, 
d'optimiser les performances et d'offrir une expérience de jeu fluide et divertissante pour tous les participants.
Nous changerions par exemple la forme du joueur par une moto (comme dans le film), et nous ajouterions également un système de points pour faire un classement du meilleur au moins bon joueur ( et ne plus avoir que le vainqueur) 
Nous sommes enthousiastes à l'idée de poursuivre ce projet et d'aboutir à une version finale exceptionnelle du jeu "Torn".


## Auteurs

- Guillaume Egmmann
- Ines Beaunoir
- Philomène Lamonnerie 
