import pygame
import sys
import time

pygame.init()

# Définir les dimensions de la fenêtre
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("°°°°°°°° GAME : TORN °°°°°°°°")



clock = pygame.time.Clock()



class Player:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.vel = 5
        self.direction = "RIGHT" #on initialise la direction à droite

    def draw(self, win):
        pygame.draw.rect(win, self.color, (self.x, self.y, self.width, self.height))

    def move(self):
        if self.direction == "UP":
            self.y -= self.vel
        elif self.direction == "DOWN":
            self.y += self.vel
        elif self.direction == "LEFT":
            self.x -= self.vel
        elif self.direction == "RIGHT":
            self.x += self.vel
        
       

class RestartButton:
    def __init__(self, x, y, width, height, text, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
        self.color = color
    
    def draw(self, win):
        pygame.draw.rect(win, self.color, (self.x, self.y, self.width, self.height))
        font = pygame.font.Font(None, 36)
        text_surface = font.render(self.text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=(self.x + self.width / 2, self.y + self.height / 2))
        win.blit(text_surface, text_rect)


def main():
    
    player = Player(50, 50, 20, 20, (255, 0, 0))
    restart_button = RestartButton(screen_width // 2 - 50, screen_height // 2 - 25, 100, 50, "Restart", (0, 255, 0))
    game_over= False
    restart_displayed = False
    game_over_time = None

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()

        if game_over:
            if not restart_displayed:
                game_over_time = time.time()
                restart_displayed = True

            if time.time() - game_over_time > 3:
                if keys[pygame.K_SPACE]:  # Restart the game on Space key press
                    game_over = False
                    player.x = 50
                    player.y = 50
                    player.direction ="RIGHT"
                    restart_displayed = False
        else:
            # Changer la direction en fonction des touches
            if keys[pygame.K_UP]:
                player.direction = "UP"
            elif keys[pygame.K_DOWN]:
                player.direction = "DOWN"
            elif keys[pygame.K_LEFT]:
                player.direction = "LEFT"
            elif keys[pygame.K_RIGHT]:
                player.direction = "RIGHT"

        #déplacer le joueur
        player.move()

         # Vérifier les collisions avec les bords de l'écran
        if player.x < 0 or player.x > screen_width - player.width or player.y < 0 or player.y > screen_height - player.height:
            game_over = True 
            print("GAME OVER")

        screen.fill((0, 0, 0))  # Efface l'écran
        player.draw(screen)  # Dessine le joueur

 
        if game_over:
            font = pygame.font.Font(None, 50)
            text_surface = font.render("GAME OVER", True, (255, 0, 0))
            text_rect = text_surface.get_rect(center=(screen_width // 2, screen_height // 2 - 50))
            screen.blit(text_surface, text_rect)

            if restart_displayed:
                restart_button.draw(screen)

        pygame.display.update()  # Met à jour l'affichage
        clock.tick(60)  # Limite le taux de rafraîchissement à 60 FPS

    pygame.quit()



if __name__== "__main__":
    main()