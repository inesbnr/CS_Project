import socket, tqdm, threading, pygame
from client import Client



clients = []


def receive_string(so: socket.socket, encoding = "utf-8") -> str:
    """
    Receive a string from the socket by first reasing the size of the str
    and the then the string itself
    """
    length = int.from_bytes(so.recv(4))
    return so.recv(length).decode(encoding)

def network(client):
    while True:
        try:
            #print("9")
            message= client.recv(1024).decode('utf-8')
            #print("8")
            if len(message) == 0: break
            print(message) #affiche le message du client
            #print("7")
            for other_client in clients:
                print("1")
                if other_client.client_socket != client:
                    #print("2")
                    print(f'{other_client.client_socket}//////////////////{client}')
                    other_client.client_socket.send(message.encode('utf-8'))
                    #print("3")
        except Exception as e:
            #print("oooooooooooooooooooooooooooooooooooooo")
            print(f"Error: {e}")
            break
        





def server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(f'==== {server_socket} ====')
    server_socket.bind(('172.21.72.166', 4444))

    server_socket.listen(4) #4 clients max

    
    while True:
        
        cSocket, cAddr = server_socket.accept()
        #newClient = Client(client_socket, client_addr)
        newClient = Client(cSocket, cAddr)

        print(f'New connection from {newClient.client_addr} : {newClient.client_socket}') #affiche nouvelle connexion
        clients.append(newClient)
        client_thread = threading.Thread(target =network, args= (newClient.client_socket,))
        #on précise pour ne pas assginer une valeur au group ou autre chose dans le Thread
        client_thread.start()
        #client_thread.join()
        #newClient.client_socket.close()
    



server()






   


"""
    file_name   = receive_string(client_socket)
    file_length = int.from_bytes(client_socket.recv(4))
    print(f'Receiving {file_name} of size {file_length} bytes')


    received_bytes = 0
    with open(file_name, 'wb') as fh:
        progess = tqdm.tqdm(total=file_length)
        while received_bytes < file_length:
            buffer = client_socket.recv(1024)
            fh.write(buffer)
            received_bytes += len(buffer)
            progess.update(len(buffer))
"""