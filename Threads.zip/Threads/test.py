import pygame
import sys
import time
import threading, socket
import random

other_players = {}
game_over =True


def receive_messages(client_socket):
     running = True
     while running:
        try:
            #print("A")
            message = client_socket.recv(1024).decode('utf-8')
            #print("B")
            if len(message) == 0: break
            #print("C")
            infoRecu = message.split("#")
            newInfo = infoRecu[:3]
            newInfo.append("".join(filter(str.isalpha,infoRecu[3])))
            other_players[client_socket] = (int(newInfo[0]), int(newInfo[1]), newInfo[2], newInfo[3])
            print(f"Received: {newInfo}\n=========")
            time.sleep(0.01)
            #if len(infoRecu)>= 4:
                #x,y, color, direction = map(int, infoRecu[:3])        #essaie gpt
                #other_players[client_socket] = (x, y, (color, direction)) # idem
                #for key, value in other_players.items():
                #   print(f'Clé: {key}, Valeur: {str(value)}')

        except Exception as e:
            print(f"Error: {e}")
            break
        #return infoRecu
        

               
            

def connect(player):  
        sck = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sck.connect(('172.21.72.166', 4444))
        #print(sck.getsockname() ,"hello")
        #print(sck)
        
        print("Connected")

        received_thread = threading.Thread(target=receive_messages, args=(sck,))
        received_thread.start()
        #received_thread.join() #attendre que le thread soit fini
        #returned_value = received_thread.infoRecu if hasattr(received_thread, 'infoRecu') else None

        running =True
        while running:
            #message = input("Entrez une commande: ")            #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            sck.send((player.infos()).encode())
            print(f'=======\n{player.infos()}') 
            time.sleep(0.01)
            #print("Done")

        sck.close()





#========================================================================================================






pygame.init()

# Définir les dimensions de la              ------   FENETRE VIDE   -------
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("°°°°°°°° GAME : TORN °°°°°°°°")


#Colors 
BLACK =(0,0,0)
WHITE =(255, 255, 255)
font = pygame.font.Font(None,36)

clock = pygame.time.Clock()



class Player:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.vel = 5
        self.direction = "RIGHT" #on initialise la direction à droite

    def infos(self) -> str:
        info = [str(self.x), str(self.y), str(self.color), str(self.direction)]
        mess = "#".join(info)
        #info = [str(self.item) for item in info]
        return mess

    def ToString(self):
        info = [str(self.x), str(self.y), str(self.direction)] #couleur enlevée
        infOtherPlayer = " ".join(info)
        print(infOtherPlayer)

        

        
    

    def draw(self, win):
        pygame.draw.rect(win, (self.color), (self.x, self.y, self.width, self.height))

    def move(self):
        if self.direction == "UP":
            self.y -= self.vel
        elif self.direction == "DOWN":
            self.y += self.vel
        elif self.direction == "LEFT":
            self.x -= self.vel
        elif self.direction == "RIGHT":
            self.x += self.vel

    
       

class RestartButton:
    def __init__(self, x, y, width, height, text, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
        self.color = color
    
    def draw(self, win):
        pygame.draw.rect(win, self.color, (self.x, self.y, self.width, self.height))
        font = pygame.font.Font(None, 36)
        text_surface = font.render(self.text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=(self.x + self.width / 2, self.y + self.height / 2))
        win.blit(text_surface, text_rect)

def accueil():
    screen.fill(BLACK) #effacer l'ecran / enfin le mettre noir


    text = font.render("Connexion Réussie !", True, WHITE)
    text_rect = text.get_rect(center = (screen_width//2,200))

    start_text = font.render("Appyer sur Espace pour démarrer le jeu", True, WHITE)
    start_rect = start_text.get_rect(center=(screen_width//2,400))
    screen.blit(text,text_rect)
    screen.blit(start_text, start_rect)
    pygame.display.update()

    space_pressed = False  # Variable pour suivre si la touche 
    while not space_pressed:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            # Capture l'appui sur la touche Espace
            print("1")
            keys = pygame.key.get_pressed()
            print("2")
            if keys[pygame.K_DOWN]:
                print("3")
                space_pressed = True
        
        return not space_pressed  # Retourne False lorsque la 

def logique_jeu(player):

        keys = pygame.key.get_pressed()

        if game_over:
            if not restart_displayed:
                game_over_time = time.time()
                restart_displayed = True

            if time.time() - game_over_time > 3:
                if keys[pygame.K_SPACE]:  # Restart the game on Space key press
                    game_over = False
                    player.x = 50
                    player.y = 50
                    player.direction ="RIGHT"
                    restart_displayed = False
        else:
            # Changer la direction en fonction des touches
            if keys[pygame.K_UP]:
                player.direction = "UP"
            elif keys[pygame.K_DOWN]:
                player.direction = "DOWN"
            elif keys[pygame.K_LEFT]:
                player.direction = "LEFT"
            elif keys[pygame.K_RIGHT]:
                player.direction = "RIGHT"

        #déplacer le joueur
        player.move()

         # Vérifier les collisions avec les bords de l'écran
        if player.x < 0 or player.x > screen_width - player.width or player.y < 0 or player.y > screen_height - player.height:
            game_over = True 
            print("GAME OVER")

        screen.fill((0, 0, 0))  # Efface l'écran
        player.draw(screen)  # Dessine le joueur


def draw_other_players():
        for player_info in other_players.values():
            if len(player_info) >=4:
                x, y, color_str, direction = player_info

                
                #color = map(int, color)
                color_str = color_str.strip('()')
                color_values = color_str.split(',')
                color = [int(x) for x in color_values]
                #print(f"ma COuleur de Drapeau{color}")
                #print(f"AAAAAAAAAAAA VOOOOOOOOOOOOOOOOTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT: {str(type(color))}")
                #if player.color != color:
                try:
                    color = pygame.Color(color)
                except ValueError:
                    color = pygame.Color("white")
                    print(f"JE pas COOOOOOOOOOOOOOOOuLEUUUUUUUUUUUUUUUR")
                other_player = Player(x, y, 20, 20, color)
                other_player.direction = direction
                other_player.draw(screen)
            else : 
                print("JE T'aime PAAAS")
                print(player_info)


#def draw_other_clients():



def main():
    x = random.randint(50,600)
    y = random.randint(50, 500)
    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)

    player = Player(x, y, 20, 20, (r, g, b))
    game_over= False
    #....................................................................
    tCon = threading.Thread(target = connect, args=(player,))
    tCon.start()
    #....................................................................


    restart_button = RestartButton(screen_width // 2 - 50, screen_height // 2 - 25, 100, 50, "Restart", (0, 255, 0))
    
    restart_displayed = False
    game_over_time = None

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
       
               
        
        keys = pygame.key.get_pressed()

        if game_over:
            if not restart_displayed:
                game_over_time = time.time()
                restart_displayed = True

            if time.time() - game_over_time > 3:
                if keys[pygame.K_SPACE]:  # Restart the game on Space key press
                    game_over = False
                    player.x = 50
                    player.y = 50
                    player.direction ="RIGHT"
                    restart_displayed = False
        else:
            # Changer la direction en fonction des touches
            if keys[pygame.K_UP]:
                player.direction = "UP"
            elif keys[pygame.K_DOWN]:
                player.direction = "DOWN"
            elif keys[pygame.K_LEFT]:
                player.direction = "LEFT"
            elif keys[pygame.K_RIGHT]:
                player.direction = "RIGHT"

        #déplacer le joueur
        player.move()

         # Vérifier les collisions avec les bords de l'écran
        if player.x < 0 or player.x > screen_width - player.width or player.y < 0 or player.y > screen_height - player.height:
            game_over = True 
            print("GAME OVER")

        #screen.fill((0, 0, 0))  # Efface l'écran
        player.draw(screen)  # Dessine le joueur
        #tDraw =threading.Thread(target=player.draw, args=(screen,))
        #tDraw.start()
        # Dessinez les autres joueurs
        tDrawOther = threading.Thread(target=draw_other_players)
        tDrawOther.start()
        tDrawOther.join()

        #tDraw.join()
        #tDrawOther.join()

        """
        for player_info in other_players.items():
            x2, y2, color, direction = player_info
            color = map(int, color)
            color = pygame.Color(color)
            other_player = Player(x2, y2, 20, 20, color)  # Crée un objet joueur pour l'autre joueur
            other_player.direction = direction  # Mettez à jour la direction
            other_player.draw(screen)  # Dessinez l'autre joueur
            #other_player.ToString()
        """
        if game_over:
            font = pygame.font.Font(None, 50)
            text_surface = font.render("GAME OVER", True, (255, 0, 0))
            text_rect = text_surface.get_rect(center=(screen_width // 2, screen_height // 2 - 50))
            screen.blit(text_surface, text_rect)

            if restart_displayed:
                screen.fill((0, 0, 0))
                restart_button.draw(screen)

        pygame.display.update()  # Met à jour l'affichage
        clock.tick(60)  # Limite le taux de rafraîchissement à 60 FPS
        time.sleep(0.1)
    pygame.quit()



#if __name__== "__test__":


main()
