import socket, os, pygame, threading
from pygame.locals import QUIT
from client import Client


def receive_messages(client_socket):
     running = True
     while running:
        try:
            #print("A")
            message = client_socket.recv(1024).decode('utf-8')
            #print("B")
            if len(message) == 0: break
            #print("C")
            print(f"Received: {message}")
        except Exception as e:
            #print("DDDDDDDDDDDDDDDDDDDDDDDDDDDDD")
            print(f"Error: {e}")
            break
        

               
            

def connect():  
        sck = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sck.connect(('172.21.72.166', 1111))
        #print(sck.getsockname() ,"hello")
        #print(sck)

        print("Connected")

        received_thread = threading.Thread(target=receive_messages, args=(sck,))
        received_thread.start()

        running =True
        while running:
            message = input("Entrez une commande: ")
            sck.send(message.encode())
            #print("Done")

        sck.close()



#tScreen = threading.Thread(target=display_game).start()
connect()