import socket
import threading

SERVER_ID = '172.21.72.199'
SERVER_PORT = 4441
clients = []

# Use a flag to track if the game has started
game_started = False

# Function to broadcast a message to all connected clients
def broadcast(message):
    for client_socket in clients:
        try:
            client_socket.send(message.encode('utf-8'))
        except Exception as e:
            print(f"Error broadcasting message to {client_socket}: {e}")

def handle_client(client_socket):
    try:
        while True:
            message = client_socket.recv(1024).decode('utf-8')
            if len(message) ==0 :
                break  # Exit the loop when a client disconnects
            print(message)
            if message == "START":
                broadcast("Game started")
                print("Game started")
    except Exception as e:
        print(f"Error with client {client_socket}: {e}")
    finally:
        client_socket.close()
        clients.remove(client_socket)
        print(f"Client {client_socket} disconnected")

def server():
    
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((SERVER_ID, SERVER_PORT))
    server_socket.listen(4)  # Maximum of 4 clients

    print(f"Server is operational on {SERVER_ID}:{SERVER_PORT}")

    while True:
        client_socket, client_addr = server_socket.accept()
        clients.append(client_socket)
        print(f'New connection from {client_addr}')

        client_handler = threading.Thread(target=handle_client, args=(client_socket,))
        client_handler.start()

# Start the server
server()
