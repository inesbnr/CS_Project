import socket, os, pygame, threading
from pygame.locals import QUIT


SERVER_ID='172.21.72.199'
SERVER_PORT=4441
class Client:
    
    def __init__(self, client_socket, client_addr, data=""):
        self.client_socket = client_socket
        self.client_addr = client_addr
        self.data = data


#//////////////////////////////// PAS FAN ///////////////////////

def receive_messages(client_socket):
     running = True
     while running:
        try:
            message = client_socket.recv(1024).decode('utf-8')
            if len(message) == 0: break
            print(f"Received: {message}")
        except Exception as e:
            print(f"Error: {e}")
            break
        
"""
def connect():  
    sck = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sck.connect((SERVER_ID, SERVER_PORT))
            #print(sck.getsockname() ,"hello")
            #print(sck)

    print("Connected")

    received_thread = threading.Thread(target= receive_messages, args=(sck,))
    received_thread.start()

    running =True
    while running:
        message = input("Entrez une commande: ")
        sck.send(message.encode())
                #print("Done")

        sck.close()"""



if __name__ == '__main__':
    print("gros  TESTTTT")
    #connect()
    

