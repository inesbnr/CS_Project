import socket, os, pygame, threading
from pygame.locals import QUIT
from client import Client
import time

SERVER_ID='172.21.72.199'
SERVER_PORT=4441

def receive_messages(client_socket):
     running = True
     while running:
        try:
            #print("A")
            message = client_socket.recv(1024).decode('utf-8')
            #print("B")
            if len(message) == 0: break
            #print("C")
            print(f"Received: {message}")
        except Exception as e:
            #print("DDDDDDDDDDDDDDDDDDDDDDDDDDDDD")
            print(f"Error: {e}")
            break
        
# Classe pour représenter le joueur
class Player:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.vel = 5
        self.direction = "RIGHT" #on initialise la direction à droite

# Fonction pour obtenir les informations du joueur sous forme de chaîne
    def infos(self) -> str:
        info = [str(self.x), str(self.y), str(self.color), str(self.direction)]
        mess = "#".join(info)
        #info = [str(self.item) for item in info]
        return mess

#affichage
    def ToString(self):
        info = [str(self.x), str(self.y), str(self.direction)] #couleur enlevée
        infOtherPlayer = " ".join(info)
        print(infOtherPlayer)

# Fonction pour dessiner le joueur        
    def draw(self, win):
        pygame.draw.rect(win, (self.color), (self.x, self.y, self.width, self.height))

# Fonction pour déplacer le joueur
    def move(self):
        if self.direction == "UP":
            self.y -= self.vel
        elif self.direction == "DOWN":
            self.y += self.vel
        elif self.direction == "LEFT":
            self.x -= self.vel
        elif self.direction == "RIGHT":
            self.x += self.vel
                     
