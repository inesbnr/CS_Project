# Importation des modules nécessaires
import pygame
import sys
import time
import threading, socket
import random

SERVER_ID = '172.21.72.199'
SERVER_PORT = 4441

class ConnectButton:
        def __init__(self, x, y, width, height, text, color, hover_color):
            self.rect = pygame.Rect(x, y, width, height)
            self.text = text
            self.color = color
            self.hover_color = hover_color
            self.pressed = False  # Nouvel attribut pour gérer l'état du bouton

        # Reste du code de la classe

        def is_pressed(self):
            return self.pressed

        def draw(self, screen, font):
            color = self.hover_color if self.rect.collidepoint(pygame.mouse.get_pos()) else self.color
            pygame.draw.rect(screen, color, self.rect)
            text_surface = font.render(self.text, True, Game.WHITE)  # Utilisez Game.WHITE
            text_rect = text_surface.get_rect(center=self.rect.center)
            screen.blit(text_surface, text_rect)

class StartGameButton:
        def __init__(self, x, y, width, height, text, color, hover_color):
            self.rect = pygame.Rect(x, y, width, height)
            self.text = text
            self.color = color
            self.hover_color = hover_color
            self.pressed = False  # Attribute to track if the button is pressed

        def is_pressed(self):
            return self.pressed

        def draw(self, screen, font):
            color = self.hover_color if self.rect.collidepoint(pygame.mouse.get_pos()) else self.color
            pygame.draw.rect(screen, color, self.rect)
            text_surface = font.render(self.text, True, Game.WHITE)  # Utilisez Game.WHITE
            text_rect = text_surface.get_rect(center=self.rect.center)
            screen.blit(text_surface, text_rect)

class RestartButton:
        def __init__(self, x, y, width, height, text, color):
            self.x = x
            self.y = y
            self.width = width
            self.height = height
            self.text = text
            self.color = color

        # Fonction pour dessiner le bouton de redémarrage
        def draw(self, win):
            pygame.draw.rect(win, self.color, (self.x, self.y, self.width, self.height))
            text_surface = Game.font.render(self.text, True, (255, 255, 255))
            text_rect = text_surface.get_rect(center=(self.x + self.width / 2, self.y + self.height / 2))
            win.blit(text_surface, text_rect)

class Game:
    pygame.init() 
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    font = pygame.font.Font(None, 36)

    def __init__(self):
        self.screen_width = 800
        self.screen_height = 600
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("JEU TRON")
        self.clock = pygame.time.Clock()
        self.player = None
        self.other_players = {}
        self.game_over = False


    def logique_jeu(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_UP]:
            self.player.direction = "UP"
        elif keys[pygame.K_DOWN]:
            self.player.direction = "DOWN"
        elif keys[pygame.K_LEFT]:
            self.player.direction = "LEFT"
        elif keys[pygame.K_RIGHT]:
            self.player.direction = "RIGHT"

        self.player.move()

        if self.player.x < 0 or self.player.x > self.screen_width - self.player.width or \
           self.player.y < 0 or self.player.y > self.screen_height - self.player.height:
            self.game_over = True
            print("GAME OVER")

    def draw_other_players(self):
        for player_info in self.other_players.values():
            x, y, color_str, direction = player_info

            color_str = color_str.strip('()')
            color_values = color_str.split(',')
            color = [int(x) for x in color_values]

            try:
                color = pygame.Color(color)
            except ValueError:
                color = pygame.Color("white")

            other_player = self.Player(x, y, 20, 20, color)
            other_player.direction = direction
            other_player.draw(self.screen)

    def run(self):
        self.connect()
        
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            self.logique_jeu()
            self.draw_other_players()
            
            self.screen.fill(self.BLACK)
            self.player.draw(self.screen)
            pygame.display.update()
            self.clock.tick(60)

        pygame.quit()

class Player:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.vel = 5
        self.direction = "RIGHT"
        self.sck = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.game_started=False
        
    
    
    def connect(self):
        sck = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sck.connect((SERVER_ID, SERVER_PORT))
            print("Connected")
        except Exception as e:
            print(f"Error connecting to the server: {e}")
            return  # Return early if the connection fails

        self.sck = sck  # Assurez-vous d'assigner le socket connecté à l'attribut de la classe

    
        received_thread = threading.Thread(target=self.receive_messages)
        received_thread.start()

        running = True
        while running:
            try:
                sck.send(self.infos().encode('utf-8'))
                time.sleep(0.01)
            except Exception as e:
                print(f"Error sending data: {e}")
                break



    def send_start_game_message(self):
        
        self.sck.send("START".encode('utf-8'))
        

    def receive_messages(self):
        running = True
        while running:
            try:
                message = self.sck.recv(1024).decode('utf-8')
                if len(message) == 0:
                    break
                if message=='Game started':
                    
                    self.game_started=True # faut renvoyer dans le main un truc gamestarted=true

                    
                else:
                    info_recu = message.split("#")
                    new_info = info_recu[:3]
                    newInfo = new_info + ["".join(filter(str.isalpha, info_recu[3]))]
                    self.other_players[self.sck] = (int(newInfo[0]), int(newInfo[1]), newInfo[2], newInfo[3])
                    time.sleep(0.01)
            except Exception as e:
                print(f"Error: {e}")
                break



    def infos(self):
        info = [str(self.x), str(self.y), str(self.color), self.direction]
        return "#".join(info)

    def move(self):
        if self.direction == "UP":
            self.y -= self.vel
        elif self.direction == "DOWN":
            self.y += self.vel
        elif self.direction == "LEFT":
            self.x -= self.vel
        elif self.direction == "RIGHT":
            self.x += self.vel

    def draw(self, win):
        pygame.draw.rect(win, self.color, (self.x, self.y, self.width, self.height))

