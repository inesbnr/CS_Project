import test
# Importation des modules nécessaires
import pygame
import sys
import time
import threading
import random
game=test.Game()

def main():
    
  

    # Initialisation de Pygame
    

    # Définition des dimensions de la fenêtre de jeu
    screen_width = 800
    screen_height = 600
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("JEU TRON")
    clock=pygame.time.Clock()

    # Créez la police que vous souhaitez utiliser pour les boutons
    font = pygame.font.Font(None, 36)

    # Générer des valeurs aléatoires pour la position et la couleur initiale du joueur
    
    x = random.randint(50,600)
    y = random.randint(50, 500)
    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)
    
    
    game_over= False
    
    
    
    connect_button = test.ConnectButton(300, 200, 200, 50, "Connexion", (0, 255, 0), (0, 200, 0))
    button_pressed = False

    while not button_pressed:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if connect_button.rect.collidepoint(event.pos):
                    if connect_button.text == "Connexion":
                        connect_button.pressed = True  # Marquez le bouton comme pressé
                        button_pressed = True

        # Affiche le bouton sur l'écran
        connect_button.draw(screen, font)
        pygame.display.update()



    #pour crééer la connection de chaque client 
    if button_pressed==True:
        # Créer un joueur initial avec des valeurs aléatoires
   
        player = test.Player(x, y, 20, 20, (r, g, b))
        tCon = threading.Thread(target = player.connect)
        tCon.start()
   
    
    game_started=player.game_started

    #affciher qui est connecté
    screen.fill(test.Game.BLACK) #effacer l'ecran / enfin le mettre noir
    #faire un bouton pour lancer le jeu de açon synchrone entre tout les clients
    start_game_button = test.StartGameButton(300, 300, 200, 50, "Start Game", (0, 0, 255), (0, 0, 200))
    start_game_pressed = False  # Variable to track if the Start Game button is pressed
    screen.fill(test.Game.BLACK)

    while not game_started:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if start_game_button.rect.collidepoint(event.pos):
                    if start_game_button.text == "Start Game":
                        start_game_button.pressed = True
                        start_game_pressed = True

        # Affiche le bouton sur l'écran
        start_game_button.draw(screen, font)
        pygame.display.update()

        if start_game_pressed:
            tSendStartGame = threading.Thread(target=player.send_start_game_message)
            
            tSendStartGame.start()
            print("commence")
            break
        game_started=player.game_started
            

    #print(other_players)
    screen.fill(test.Game.BLACK) #effacer l'ecran / enfin le mettre noir
    #Lancer un thread pour gérer la communication avec le serveur
   
    
    restart_button = test.RestartButton(screen_width // 2 - 50, screen_height // 2 - 25, 100, 50, "Restart", (0, 255, 0))
    
    restart_displayed = False
    game_over_time = None
    print("4")
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        keys = pygame.key.get_pressed()

        if game_over:
            if not restart_displayed:
                game_over_time = time.time()
                restart_displayed = True

            if time.time() - game_over_time > 3:
                if keys[pygame.K_SPACE]:  # Restart the game on Space key press
                    game_over = False
                    player.x = 50
                    player.y = 50
                    player.direction ="RIGHT"
                    restart_displayed = False
        else:
            # Changer la direction en fonction des touches
            if keys[pygame.K_UP]:
                player.direction = "UP"
            elif keys[pygame.K_DOWN]:
                player.direction = "DOWN"
            elif keys[pygame.K_LEFT]:
                player.direction = "LEFT"
            elif keys[pygame.K_RIGHT]:
                player.direction = "RIGHT"

        #déplacer le joueur
        player.move()

         # Vérifier les collisions avec les bords de l'écran
        if player.x < 0 or player.x > screen_width - player.width or player.y < 0 or player.y > screen_height - player.height:
            game_over = True 
            print("GAME OVER")

       
        player.draw(screen)  # Dessine le joueur
        
        tDrawOther = threading.Thread(target=game.draw_other_players)
        tDrawOther.start()
        tDrawOther.join()

        if game_over:
            font = pygame.font.Font(None, 50)
            text_surface = font.render("GAME OVER", True, (255, 0, 0))
            text_rect = text_surface.get_rect(center=(screen_width // 2, screen_height // 2 - 50))
            screen.blit(text_surface, text_rect)

            if restart_displayed:
                screen.fill((0, 0, 0))
                restart_button.draw(screen)

        pygame.display.update()  # Met à jour l'affichage
        
        clock.tick(60)  # Limite le taux de rafraîchissement à 60 FPS
        time.sleep(0.1)
    pygame.quit()


if __name__ == "__main__":
    main()
