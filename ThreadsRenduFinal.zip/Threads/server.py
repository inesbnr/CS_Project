import socket, tqdm, threading, pygame, time
from client import Client


clients = []
coordonnees= []
i=0

def receive_string(so: socket.socket, encoding = "utf-8") -> str:
    length = int.from_bytes(so.recv(4))
    return so.recv(length).decode(encoding)

def sendDead(client):
    client.send("dead".encode("utf-8"))


def network(client):
    global i
    while True:
        try:
            message= client.recv(1024).decode('utf-8')
            if len(message) == 0: break
            #print('===========================',message,'=========================') #affiche le message du client
            

            xCoo, yCoo = message.split("#")[:2]
            xCoo =int(xCoo)
            yCoo =int(yCoo)
            coordonnee = [xCoo, yCoo]
            if coordonnee not in coordonnees: 
                coordonnees.append(coordonnee)
                #diagonale haut/droit
                coordonnees.append([xCoo+1,yCoo+1])
                coordonnees.append([xCoo+2,yCoo+2])
                coordonnees.append([xCoo+3,yCoo+3])
                coordonnees.append([xCoo+4,yCoo+4])

                #diagonale haut/gauche
                coordonnees.append([xCoo-1,yCoo+1])
                coordonnees.append([xCoo-2,yCoo+2])
                coordonnees.append([xCoo-3,yCoo+3])
                coordonnees.append([xCoo-4,yCoo+4])

                #diagonale bas/droit
                coordonnees.append([xCoo+1,yCoo-1])
                coordonnees.append([xCoo+2,yCoo-2])
                coordonnees.append([xCoo+3,yCoo-3])
                coordonnees.append([xCoo+4,yCoo-4])

                #diagonale bas/gauche
                coordonnees.append([xCoo-1,yCoo-1])
                coordonnees.append([xCoo-2,yCoo-2])
                coordonnees.append([xCoo-3,yCoo-3])
                coordonnees.append([xCoo-4,yCoo-4])

                #ligne droit
                coordonnees.append([xCoo+1,yCoo])
                coordonnees.append([xCoo+2,yCoo])
                coordonnees.append([xCoo+3,yCoo])
                coordonnees.append([xCoo+4,yCoo])

                #ligne gauche
                coordonnees.append([xCoo-1,yCoo])
                coordonnees.append([xCoo-2,yCoo])
                coordonnees.append([xCoo-3,yCoo])
                coordonnees.append([xCoo-4,yCoo])

                #ligne haut
                coordonnees.append([xCoo,yCoo+1])
                coordonnees.append([xCoo,yCoo+2])
                coordonnees.append([xCoo,yCoo+3])
                coordonnees.append([xCoo,yCoo+4])
                

                #ligne bas
                coordonnees.append([xCoo,yCoo-1])
                coordonnees.append([xCoo,yCoo-2])
                coordonnees.append([xCoo,yCoo-3])
                coordonnees.append([xCoo,yCoo-4])
                

                print("New coordinates added:", coordonnee)
            else:
                i+=1
                print(i)

                
                if i == 3 : # A changer pour jouer avec plus de 2 joueurs mais eviter les collision aux spawns des vers de terre
                    for c in clients:
                        c.client_socket.send("dead".encode("utf-8"))
                    #print("Mission failed!") 
                    i = 0

            for other_client in clients:
                print("1")
                if other_client.client_socket != client:
                    other_client.client_socket.send(message.encode('utf-8'))
                    print("3")
        except Exception as e:
            print(f"Error: {e}")
            break
        



clock = pygame.time.Clock()

def server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(f'==== {server_socket} ====')
    server_socket.bind(("172.21.72.166", 4444)) # ADDRESS IP and PORT to change
    server_socket.listen(4) #4 clients max

    
    while True:
        
        cSocket, cAddr = server_socket.accept()
        newClient = Client(cSocket, cAddr)

        print(f'New connection from {newClient.client_addr} : {newClient.client_socket}') #affiche nouvelle connexion
        clients.append(newClient)
        i =0
        client_thread = threading.Thread(target =network, args= (newClient.client_socket,))
        
        client_thread.start()
        time.sleep(0.2) #0.2 pour 5 fps
     
    
    
    



server()






