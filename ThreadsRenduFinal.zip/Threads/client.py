import socket, os, pygame, threading
from pygame.locals import QUIT



class Client:
    
    def __init__(self, client_socket, client_addr, data=""):
        self.client_socket = client_socket
        self.client_addr = client_addr
        self.data = data


#//////////////////////////////// PAS FAN ///////////////////////

def receive_messages(client_socket):
     running = True
     while running:
        try:
            message = client_socket.recv(1024).decode('utf-8')
            if len(message) == 0: break
            print(f"Received: {message}")
        except Exception as e:
            print(f"Error: {e}")
            break
        


